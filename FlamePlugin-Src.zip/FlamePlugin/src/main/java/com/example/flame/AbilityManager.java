package com.example.flame;

import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class AbilityManager {

    public static void updateAbilities(Player p) {

        p.removePotionEffect(PotionEffectType.SPEED);
        p.removePotionEffect(PotionEffectType.STRENGTH);
        p.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);

        // If an admin has set a custom ability override, use that instead of rank-based logic
        if (AbilityOverrideManager.hasOverride(p.getUniqueId())) {
            for (PotionEffectType type : AbilityOverrideManager.getAbilities(p.getUniqueId())) {
                give(p, type);
            }
            return;
        }

        int rank = RankManager.getRank(p);

        if (rank >= 1 && rank <= 3) {
            give(p, PotionEffectType.SPEED);
            give(p, PotionEffectType.STRENGTH);
            give(p, PotionEffectType.FIRE_RESISTANCE);
        }

        else if (rank >= 4 && rank <= 6) {
            give(p, PotionEffectType.SPEED);
            give(p, PotionEffectType.FIRE_RESISTANCE);
        }

        else if (rank >= 7 && rank <= 10) {
            give(p, PotionEffectType.FIRE_RESISTANCE);
        }
    }

    private static void give(Player p, PotionEffectType type) {
        p.addPotionEffect(new PotionEffect(type, Integer.MAX_VALUE, 0, true, false));
    }
}