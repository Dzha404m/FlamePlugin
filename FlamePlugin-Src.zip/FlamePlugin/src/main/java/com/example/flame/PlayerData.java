package com.example.flame;

import java.util.UUID;

public class PlayerData {

    public static int getStreak(UUID uuid) {
        return FlamePlugin.getInstance().getData().getInt(uuid, "streak", 0);
    }

    public static void setStreak(UUID uuid, int value) {
        FlamePlugin.getInstance().getData().set(uuid, "streak", value);
    }

    public static void addKill(UUID uuid) {
        setStreak(uuid, getStreak(uuid) + 1);
    }

    public static void resetStreak(UUID uuid) {
        setStreak(uuid, 0);
    }
}