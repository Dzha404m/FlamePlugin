package com.example.flame;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class FlamePlugin extends JavaPlugin {

    private static FlamePlugin instance;
    private DataManager data;

    @Override
    public void onEnable() {
        instance = this;

        data = new DataManager(this);
        data.load();

        getServer().getPluginManager().registerEvents(new KillListener(), this);
        getServer().getPluginManager().registerEvents(new DeathListener(), this);
        getServer().getPluginManager().registerEvents(new JoinListener(), this);
        getServer().getPluginManager().registerEvents(new GUIListener(), this);

        CommandHandler handler = new CommandHandler();
        getCommand("setstreak").setExecutor(handler);
        getCommand("resetstreak").setExecutor(handler);
        getCommand("top").setExecutor(handler);
        getCommand("rank").setExecutor(handler);
        getCommand("abilitymanager").setExecutor(handler);
        getCommand("flame").setExecutor(handler);

        // 🔁 update ranks + abilities every 5 seconds
        getServer().getScheduler().runTaskTimer(this, () -> {

            RankManager.updateRanks();

            for (Player p : Bukkit.getOnlinePlayers()) {
                AbilityManager.updateAbilities(p);
            }

        }, 0L, 100L);

        getLogger().info("🔥 FlamePlugin Enabled");
    }

    @Override
    public void onDisable() {
        data.save();
    }

    public static FlamePlugin getInstance() {
        return instance;
    }

    public DataManager getData() {
        return data;
    }
}