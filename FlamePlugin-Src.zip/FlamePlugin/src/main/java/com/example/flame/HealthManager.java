package com.example.flame;

import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;

public class HealthManager {

    public static void update(Player p, int streak) {

        int hearts;

        if (streak >= 5) hearts = 20;
        else if (streak == 4) hearts = 18;
        else if (streak == 3) hearts = 16;
        else if (streak == 2) hearts = 14;
        else if (streak == 1) hearts = 12;
        else hearts = 10;

        p.getAttribute(Attribute.MAX_HEALTH)
                .setBaseValue(hearts * 2);
    }
}