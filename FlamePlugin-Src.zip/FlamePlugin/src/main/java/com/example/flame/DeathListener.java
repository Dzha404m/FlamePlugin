package com.example.flame;

import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.potion.PotionEffectType;

public class DeathListener implements Listener {

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {

        Player p = e.getEntity();

        PlayerData.resetStreak(p.getUniqueId());

        p.removePotionEffect(PotionEffectType.SPEED);
        p.removePotionEffect(PotionEffectType.STRENGTH);
        p.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);

        double current = p.getAttribute(Attribute.MAX_HEALTH).getBaseValue();
        p.getAttribute(Attribute.MAX_HEALTH)
                .setBaseValue(Math.max(20, current - 4));
    }
}