package com.example.flame;

import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Tracks custom ability overrides set via /abilitymanager GUI.
 * When a player has an override, AbilityManager uses this instead of rank-based logic.
 */
public class AbilityOverrideManager {

    // uuid -> set of active ability types
    private static final Map<UUID, Set<PotionEffectType>> overrides = new HashMap<>();

    public static boolean hasOverride(UUID uuid) {
        return overrides.containsKey(uuid);
    }

    public static Set<PotionEffectType> getAbilities(UUID uuid) {
        return overrides.computeIfAbsent(uuid, k -> new HashSet<>());
    }

    public static void setOverride(UUID uuid, Set<PotionEffectType> abilities) {
        overrides.put(uuid, new HashSet<>(abilities));
    }

    public static void removeOverride(UUID uuid) {
        overrides.remove(uuid);
    }

    public static void toggle(UUID uuid, PotionEffectType type) {
        Set<PotionEffectType> set = getAbilities(uuid);
        if (set.contains(type)) {
            set.remove(type);
        } else {
            set.add(type);
        }
        overrides.put(uuid, set);
    }
}
