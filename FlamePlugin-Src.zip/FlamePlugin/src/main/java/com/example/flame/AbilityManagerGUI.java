package com.example.flame;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class AbilityManagerGUI {

    public static final String TITLE_PREFIX = "§5§lAbilities: ";

    // Slot positions for each ability
    public static final int SLOT_SPEED = 11;
    public static final int SLOT_STRENGTH = 13;
    public static final int SLOT_FIRE = 15;
    public static final int SLOT_RESET = 22;

    public static void open(Player admin, Player target) {
        String title = TITLE_PREFIX + target.getName();
        Inventory inv = Bukkit.createInventory(null, 27, title);

        // Black glass filler
        ItemStack filler = makeFiller();
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        Set<PotionEffectType> active;
        if (AbilityOverrideManager.hasOverride(target.getUniqueId())) {
            active = AbilityOverrideManager.getAbilities(target.getUniqueId());
        } else {
            // Seed from rank-based defaults so the GUI starts accurate
            active = AbilityOverrideManager.getAbilities(target.getUniqueId());
            int rank = RankManager.getRank(target);
            if (rank >= 1 && rank <= 3) {
                active.add(PotionEffectType.SPEED);
                active.add(PotionEffectType.STRENGTH);
                active.add(PotionEffectType.FIRE_RESISTANCE);
            } else if (rank >= 4 && rank <= 6) {
                active.add(PotionEffectType.SPEED);
                active.add(PotionEffectType.FIRE_RESISTANCE);
            } else if (rank >= 7 && rank <= 10) {
                active.add(PotionEffectType.FIRE_RESISTANCE);
            }
            AbilityOverrideManager.setOverride(target.getUniqueId(), active);
        }

        inv.setItem(SLOT_SPEED,    makeAbilityItem(Material.SUGAR,        "§bSpeed",           PotionEffectType.SPEED,           active));
        inv.setItem(SLOT_STRENGTH, makeAbilityItem(Material.BLAZE_POWDER, "§cStrength",         PotionEffectType.STRENGTH,         active));
        inv.setItem(SLOT_FIRE,     makeAbilityItem(Material.FIRE_CHARGE,  "§6Fire Resistance",  PotionEffectType.FIRE_RESISTANCE,  active));
        inv.setItem(SLOT_RESET,    makeResetItem());

        // Store which player this GUI is for so the click listener knows
        GUITargetStore.store(admin.getUniqueId(), target.getUniqueId());

        admin.openInventory(inv);
    }

    public static ItemStack makeAbilityItem(Material mat, String name, PotionEffectType type, Set<PotionEffectType> active) {
        boolean on = active.contains(type);
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name + (on ? " §a[ON]" : " §c[OFF]"));
        List<String> lore = new ArrayList<>();
        lore.add(on ? "§7Click to §cdisable" : "§7Click to §aenable");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack makeResetItem() {
        ItemStack item = new ItemStack(Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§cReset to Rank Defaults");
        List<String> lore = new ArrayList<>();
        lore.add("§7Removes manual override");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack makeFiller() {
        ItemStack glass = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta meta = glass.getItemMeta();
        meta.setDisplayName(" ");
        glass.setItemMeta(meta);
        return glass;
    }

    public static String getTitlePrefix() {
        return TITLE_PREFIX;
    }
}
