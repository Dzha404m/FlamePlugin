package com.example.flame;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Maps an admin's UUID to the target player UUID they have open in a GUI. */
public class GUITargetStore {

    private static final Map<UUID, UUID> store = new HashMap<>();

    public static void store(UUID admin, UUID target) {
        store.put(admin, target);
    }

    public static UUID getTarget(UUID admin) {
        return store.get(admin);
    }

    public static void remove(UUID admin) {
        store.remove(admin);
    }
}
