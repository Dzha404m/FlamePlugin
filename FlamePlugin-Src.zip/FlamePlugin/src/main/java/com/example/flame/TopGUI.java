package com.example.flame;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

public class TopGUI {

    private static final String TITLE = "§6§lTop Players";

    public static void open(Player viewer) {
        // 3 rows (27 slots), centred top-10 across the middle row with padding
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);

        // Fill border with black glass
        ItemStack filler = makeFiller();
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        List<Player> sorted = RankManager.getSortedPlayers();

        // Slots 10-19 for up to 10 players (skipping edges of row 2)
        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        // For top 10, use two rows: slots 10-16 (7) and then 2nd pass 2,4,6,20,22,24 — simpler: just use 9 slots per row
        // Use row 1 (slots 0-8) and row 3 (slots 18-26) for filler, row 2 (9-17) for players
        // Actually use slots 1-9 top row and 10+ second row for up to 10
        int[] playerSlots = {1, 2, 3, 4, 5, 6, 7, 8, 10, 11};

        for (int i = 0; i < Math.min(sorted.size(), 10); i++) {
            Player p = sorted.get(i);
            int rank = i + 1;
            int streak = PlayerData.getStreak(p.getUniqueId());

            ItemStack head = makeHead(p, rank, streak);
            inv.setItem(playerSlots[i], head);
        }

        viewer.openInventory(inv);
    }

    private static ItemStack makeHead(Player p, int rank, int streak) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        meta.setOwningPlayer(p);

        // Rank colour
        String rankColor;
        if (rank == 1) rankColor = "§6"; // gold
        else if (rank == 2) rankColor = "§7"; // silver
        else if (rank == 3) rankColor = "§c"; // bronze-ish red
        else rankColor = "§f";

        meta.setDisplayName(rankColor + "#" + rank + " " + p.getName());

        List<String> lore = new ArrayList<>();
        lore.add("§7Kill Streak: §e" + streak);
        lore.add("§7Rank: " + rankColor + "#" + rank);
        lore.add("");

        // Abilities based on rank
        if (rank <= 3) {
            lore.add("§aAbilities: §fSpeed, Strength, Fire Resistance");
        } else if (rank <= 6) {
            lore.add("§aAbilities: §fSpeed, Fire Resistance");
        } else if (rank <= 10) {
            lore.add("§aAbilities: §fFire Resistance");
        } else {
            lore.add("§cAbilities: §fNone");
        }

        meta.setLore(lore);
        skull.setItemMeta(meta);
        return skull;
    }

    private static ItemStack makeFiller() {
        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = glass.getItemMeta();
        meta.setDisplayName(" ");
        glass.setItemMeta(meta);
        return glass;
    }

    public static String getTitle() {
        return TITLE;
    }
}
