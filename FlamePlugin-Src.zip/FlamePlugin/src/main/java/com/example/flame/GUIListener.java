package com.example.flame;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.potion.PotionEffectType;

import java.util.Set;
import java.util.UUID;

public class GUIListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player admin)) return;
        String title = e.getView().getTitle();

        // ── /top GUI ── (read-only, cancel all clicks)
        if (title.equals(TopGUI.getTitle())) {
            e.setCancelled(true);
            return;
        }

        // ── /abilitymanager GUI ──
        if (title.startsWith(AbilityManagerGUI.getTitlePrefix())) {
            e.setCancelled(true);
            if (e.getCurrentItem() == null || e.getCurrentItem().getType() == Material.AIR) return;

            UUID targetUUID = GUITargetStore.getTarget(admin.getUniqueId());
            if (targetUUID == null) return;

            int slot = e.getRawSlot();

            if (slot == AbilityManagerGUI.SLOT_RESET) {
                // Remove override — back to rank defaults
                AbilityOverrideManager.removeOverride(targetUUID);
                Player target = Bukkit.getPlayer(targetUUID);
                if (target != null) AbilityManager.updateAbilities(target);
                admin.closeInventory();
                admin.sendMessage("§aReset abilities to rank defaults for §f" + (target != null ? target.getName() : targetUUID));
                return;
            }

            PotionEffectType type = slotToType(slot);
            if (type == null) return;

            AbilityOverrideManager.toggle(targetUUID, type);

            // Apply immediately
            Player target = Bukkit.getPlayer(targetUUID);
            if (target != null) applyOverride(target, targetUUID);

            // Refresh GUI
            Set<PotionEffectType> active = AbilityOverrideManager.getAbilities(targetUUID);
            refreshAbilityGUI(e, active);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player admin)) return;
        String title = e.getView().getTitle();
        if (title.startsWith(AbilityManagerGUI.getTitlePrefix())) {
            GUITargetStore.remove(admin.getUniqueId());
        }
    }

    // ── Helpers ──

    private PotionEffectType slotToType(int slot) {
        if (slot == AbilityManagerGUI.SLOT_SPEED)    return PotionEffectType.SPEED;
        if (slot == AbilityManagerGUI.SLOT_STRENGTH) return PotionEffectType.STRENGTH;
        if (slot == AbilityManagerGUI.SLOT_FIRE)     return PotionEffectType.FIRE_RESISTANCE;
        return null;
    }

    private void applyOverride(Player target, UUID uuid) {
        target.removePotionEffect(PotionEffectType.SPEED);
        target.removePotionEffect(PotionEffectType.STRENGTH);
        target.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);

        Set<PotionEffectType> active = AbilityOverrideManager.getAbilities(uuid);
        for (PotionEffectType t : active) {
            target.addPotionEffect(new org.bukkit.potion.PotionEffect(t, Integer.MAX_VALUE, 0, true, false));
        }
    }

    private void refreshAbilityGUI(InventoryClickEvent e, Set<PotionEffectType> active) {
        e.getInventory().setItem(AbilityManagerGUI.SLOT_SPEED,
            AbilityManagerGUI.makeAbilityItem(Material.SUGAR, "§bSpeed", PotionEffectType.SPEED, active));
        e.getInventory().setItem(AbilityManagerGUI.SLOT_STRENGTH,
            AbilityManagerGUI.makeAbilityItem(Material.BLAZE_POWDER, "§cStrength", PotionEffectType.STRENGTH, active));
        e.getInventory().setItem(AbilityManagerGUI.SLOT_FIRE,
            AbilityManagerGUI.makeAbilityItem(Material.FIRE_CHARGE, "§6Fire Resistance", PotionEffectType.FIRE_RESISTANCE, active));
    }
}
