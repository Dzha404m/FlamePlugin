package com.example.flame;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.*;

public class RankManager {

    private static final HashMap<UUID, Integer> ranks = new HashMap<>();

    public static void updateRanks() {

        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();

        // Clear old rank teams
        for (Team t : board.getTeams()) {
            if (t.getName().startsWith("rank_")) {
                t.unregister();
            }
        }

        List<Player> sorted = getSortedPlayers();
        if (sorted.size() > 10) sorted = sorted.subList(0, 10);

        int rank = 1;

        for (Player p : sorted) {

            UUID uuid = p.getUniqueId();

            // Use override rank if set, otherwise natural position
            int effectiveRank = RankOverrideManager.hasOverride(uuid)
                    ? RankOverrideManager.getOverride(uuid)
                    : rank;

            ranks.put(uuid, effectiveRank);

            // Team name: max 16 chars
            String teamName = ("rank_" + effectiveRank + "_" + p.getName());
            if (teamName.length() > 16) teamName = teamName.substring(0, 16);

            Team team = board.registerNewTeam(teamName);
            team.prefix(net.kyori.adventure.text.Component.text("§c#" + effectiveRank + " "));
            team.addEntry(p.getName());

            int kills = PlayerData.getStreak(uuid);
            p.setPlayerListName("§c#" + effectiveRank + " §f" + p.getName() + " §7| §eKills: " + kills);

            rank++;
        }
    }

    /**
     * Returns online players sorted by streak descending.
     * Players with a rank override are placed first, sorted by override rank.
     */
    public static List<Player> getSortedPlayers() {
        List<Player> withOverride = new ArrayList<>();
        List<Player> natural = new ArrayList<>();

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (RankOverrideManager.hasOverride(p.getUniqueId())) {
                withOverride.add(p);
            } else {
                natural.add(p);
            }
        }

        withOverride.sort((a, b) ->
                RankOverrideManager.getOverride(a.getUniqueId()) -
                RankOverrideManager.getOverride(b.getUniqueId()));

        natural.sort((a, b) ->
                PlayerData.getStreak(b.getUniqueId()) -
                PlayerData.getStreak(a.getUniqueId()));

        List<Player> sorted = new ArrayList<>();
        sorted.addAll(withOverride);
        sorted.addAll(natural);
        return sorted;
    }

    public static int getRank(Player p) {
        return ranks.getOrDefault(p.getUniqueId(), 999);
    }
}