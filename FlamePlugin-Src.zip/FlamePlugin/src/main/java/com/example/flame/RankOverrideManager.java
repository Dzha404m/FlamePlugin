package com.example.flame;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Tracks manually forced ranks set by admins via /rank set or /rank change.
 * Overrides the natural streak-based rank in RankManager.
 */
public class RankOverrideManager {

    // uuid -> forced rank (1-10)
    private static final HashMap<UUID, Integer> overrides = new HashMap<>();

    public static void setRank(UUID uuid, int rank) {
        overrides.put(uuid, rank);
    }

    public static void removeRank(UUID uuid) {
        overrides.remove(uuid);
    }

    public static boolean hasOverride(UUID uuid) {
        return overrides.containsKey(uuid);
    }

    public static int getOverride(UUID uuid) {
        return overrides.getOrDefault(uuid, -1);
    }

    public static Map<UUID, Integer> getAll() {
        return overrides;
    }

    /** Swap the forced ranks of two players. If one has no override, treat their natural rank as the base. */
    public static void swapRanks(UUID a, int rankA, UUID b, int rankB) {
        overrides.put(a, rankB);
        overrides.put(b, rankA);
    }
}
