package com.example.flame;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CommandHandler implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        switch (command.getName().toLowerCase()) {

            // ── /setstreak <player> <amount> ──
            case "setstreak" -> {
                if (!sender.hasPermission("flame.admin")) {
                    sender.sendMessage("§cNo permission.");
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage("§cUsage: /setstreak <player> <amount>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null) { sender.sendMessage("§cPlayer not found."); return true; }
                int amount;
                try { amount = Integer.parseInt(args[1]); } catch (NumberFormatException ex) {
                    sender.sendMessage("§cAmount must be a number."); return true;
                }
                if (amount < 0) { sender.sendMessage("§cAmount must be 0 or greater."); return true; }
                PlayerData.setStreak(target.getUniqueId(), amount);
                HealthManager.update(target, amount);
                AbilityManager.updateAbilities(target);
                RankManager.updateRanks();
                sender.sendMessage("§aSet §f" + target.getName() + "§a's streak to §f" + amount + "§a.");
                target.sendMessage("§eYour kill streak has been set to §f" + amount + "§e by an admin.");
                return true;
            }

            // ── /resetstreak <player> ──
            case "resetstreak" -> {
                if (!sender.hasPermission("flame.admin")) {
                    sender.sendMessage("§cNo permission.");
                    return true;
                }
                if (args.length < 1) {
                    sender.sendMessage("§cUsage: /resetstreak <player>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null) { sender.sendMessage("§cPlayer not found."); return true; }
                PlayerData.resetStreak(target.getUniqueId());
                HealthManager.update(target, 0);
                AbilityManager.updateAbilities(target);
                RankManager.updateRanks();
                sender.sendMessage("§aReset §f" + target.getName() + "§a's streak.");
                target.sendMessage("§cYour kill streak has been reset by an admin.");
                return true;
            }

            // ── /top ──
            case "top" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("§cOnly players can use this command.");
                    return true;
                }
                TopGUI.open(p);
                return true;
            }

            // ── /rank set|remove|change ──
            case "rank" -> {
                if (!sender.isOp() && !sender.hasPermission("flame.rank")) {
                    sender.sendMessage("§cNo permission.");
                    return true;
                }
                if (args.length < 1) {
                    sender.sendMessage("§cUsage: /rank <set|remove|change> ...");
                    return true;
                }

                switch (args[0].toLowerCase()) {

                    case "set" -> {
                        // /rank set <player> <1-10>
                        if (args.length < 3) { sender.sendMessage("§cUsage: /rank set <player> <1-10>"); return true; }
                        Player target = Bukkit.getPlayerExact(args[1]);
                        if (target == null) { sender.sendMessage("§cPlayer not found."); return true; }
                        int rank;
                        try { rank = Integer.parseInt(args[2]); } catch (NumberFormatException ex) {
                            sender.sendMessage("§cRank must be a number 1-10."); return true;
                        }
                        if (rank < 1 || rank > 10) { sender.sendMessage("§cRank must be between 1 and 10."); return true; }
                        RankOverrideManager.setRank(target.getUniqueId(), rank);
                        RankManager.updateRanks();
                        AbilityManager.updateAbilities(target);
                        sender.sendMessage("§aForced §f" + target.getName() + "§a to rank §f#" + rank + "§a.");
                        target.sendMessage("§eYour rank has been set to §f#" + rank + "§e by an admin.");
                    }

                    case "remove" -> {
                        // /rank remove <player>
                        if (args.length < 2) { sender.sendMessage("§cUsage: /rank remove <player>"); return true; }
                        Player target = Bukkit.getPlayerExact(args[1]);
                        if (target == null) { sender.sendMessage("§cPlayer not found."); return true; }
                        RankOverrideManager.removeRank(target.getUniqueId());
                        RankManager.updateRanks();
                        AbilityManager.updateAbilities(target);
                        sender.sendMessage("§aRemoved rank override for §f" + target.getName() + "§a.");
                        target.sendMessage("§eYour rank override has been removed.");
                    }

                    case "change" -> {
                        // /rank change <player1> <player2>  — swap their ranks
                        if (args.length < 3) { sender.sendMessage("§cUsage: /rank change <player1> <player2>"); return true; }
                        Player p1 = Bukkit.getPlayerExact(args[1]);
                        Player p2 = Bukkit.getPlayerExact(args[2]);
                        if (p1 == null || p2 == null) { sender.sendMessage("§cOne or both players not found."); return true; }
                        int rank1 = RankManager.getRank(p1);
                        int rank2 = RankManager.getRank(p2);
                        RankOverrideManager.swapRanks(p1.getUniqueId(), rank1, p2.getUniqueId(), rank2);
                        RankManager.updateRanks();
                        AbilityManager.updateAbilities(p1);
                        AbilityManager.updateAbilities(p2);
                        sender.sendMessage("§aSwapped ranks of §f" + p1.getName() + " §7(was #" + rank1 + ")§a and §f" + p2.getName() + " §7(was #" + rank2 + ")§a.");
                        p1.sendMessage("§eYour rank has been swapped with §f" + p2.getName() + "§e. You are now §f#" + rank2 + "§e.");
                        p2.sendMessage("§eYour rank has been swapped with §f" + p1.getName() + "§e. You are now §f#" + rank1 + "§e.");
                    }

                    default -> sender.sendMessage("§cUsage: /rank <set|remove|change> ...");
                }
                return true;
            }

            // ── /flame help ──
            case "flame" -> {
                boolean isAdmin = sender.isOp() || sender.hasPermission("flame.admin");

                sender.sendMessage("§6§m                                        ");
                sender.sendMessage("    §6§lFlamePlugin §7- Command Help");
                sender.sendMessage("§6§m                                        ");
                sender.sendMessage("");
                sender.sendMessage("  §e§l📖 General Commands");
                sender.sendMessage("  §f/top §7- View the Top 10 players GUI");
                sender.sendMessage("  §f/flame help §7- Show this help menu");
                sender.sendMessage("");
                sender.sendMessage("  §e§l⚔ How It Works");
                sender.sendMessage("  §7Kill players to build a §fkill streak§7.");
                sender.sendMessage("  §7Higher streaks earn you a better §frank§7.");
                sender.sendMessage("");
                sender.sendMessage("  §e§l🏆 Ranks & Abilities");
                sender.sendMessage("  §c#1-3 §7→ §fSpeed §7+ §fStrength §7+ §fFire Resistance");
                sender.sendMessage("  §c#4-6 §7→ §fSpeed §7+ §fFire Resistance");
                sender.sendMessage("  §c#7-10 §7→ §fFire Resistance");
                sender.sendMessage("  §8Unranked §7→ No abilities");
                sender.sendMessage("");
                sender.sendMessage("  §e§l❤ Hearts per Kill Streak");
                sender.sendMessage("  §70 kills §7→ §f10 hearts §7(default)");
                sender.sendMessage("  §71 kill  §7→ §f12 hearts");
                sender.sendMessage("  §72 kills §7→ §f14 hearts");
                sender.sendMessage("  §73 kills §7→ §f16 hearts");
                sender.sendMessage("  §74 kills §7→ §f18 hearts");
                sender.sendMessage("  §75 kills §7→ §f20 hearts §7(max)");
                sender.sendMessage("  §cDying resets your streak & reduces hearts!");

                if (isAdmin) {
                    sender.sendMessage("");
                    sender.sendMessage("  §c§l🔧 Admin Commands");
                    sender.sendMessage("  §f/setstreak <player> <amount> §7- Set a player's streak");
                    sender.sendMessage("  §f/resetstreak <player> §7- Reset a player's streak to 0");
                    sender.sendMessage("  §f/rank set <player> <1-10> §7- Force a player's rank");
                    sender.sendMessage("  §f/rank remove <player> §7- Remove rank override");
                    sender.sendMessage("  §f/rank change <p1> <p2> §7- Swap two players' ranks");
                    sender.sendMessage("  §f/abilitymanager <player> §7- Toggle abilities via GUI");
                }

                sender.sendMessage("");
                sender.sendMessage("§6§m                                        ");
                return true;
            }

            // ── /abilitymanager <player> ──
            case "abilitymanager" -> {
                if (!sender.isOp() && !sender.hasPermission("flame.abilitymanager")) {
                    sender.sendMessage("§cNo permission.");
                    return true;
                }
                if (!(sender instanceof Player admin)) {
                    sender.sendMessage("§cOnly players can use this command.");
                    return true;
                }
                if (args.length < 1) {
                    sender.sendMessage("§cUsage: /abilitymanager <player>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null) { sender.sendMessage("§cPlayer not found."); return true; }
                AbilityManagerGUI.open(admin, target);
                return true;
            }
        }

        return false;
    }
}
