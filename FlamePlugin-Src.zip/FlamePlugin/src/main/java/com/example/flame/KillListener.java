package com.example.flame;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class KillListener implements Listener {

    @EventHandler
    public void onKill(PlayerDeathEvent e) {

        Player killer = e.getEntity().getKiller();
        if (killer == null) return;

        PlayerData.addKill(killer.getUniqueId());

        int streak = PlayerData.getStreak(killer.getUniqueId());

        HealthManager.update(killer, streak);
        AbilityManager.updateAbilities(killer);
    }
}