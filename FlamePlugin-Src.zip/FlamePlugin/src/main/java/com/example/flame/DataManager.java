package com.example.flame;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class DataManager {

    private final FlamePlugin plugin;
    private File file;
    private YamlConfiguration config;

    public DataManager(FlamePlugin plugin) {

        this.plugin = plugin;
        file = new File(plugin.getDataFolder(), "data.yml");

        if (!file.exists()) {
            file.getParentFile().mkdirs();
            try { file.createNewFile(); } catch (IOException ignored) {}
        }

        config = YamlConfiguration.loadConfiguration(file);
    }

    public int getInt(UUID uuid, String path, int def) {
        return config.getInt(uuid + "." + path, def);
    }

    public void set(UUID uuid, String path, Object value) {
        config.set(uuid + "." + path, value);
    }

    public void save() {
        try { config.save(file); } catch (IOException e) { e.printStackTrace(); }
    }

    public void load() {
        config = YamlConfiguration.loadConfiguration(file);
    }
}